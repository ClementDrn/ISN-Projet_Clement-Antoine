def a():
    global b
    c = b + 1
    print(c)

b = 1
a()

