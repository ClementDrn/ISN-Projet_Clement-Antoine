def a(B):
    if B == 1:
        return True

print(a(1))